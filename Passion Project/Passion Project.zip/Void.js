//Laat de intro verdwijnen na 6 seconden
setTimeout(function() {
    $('#intro').fadeOut('2000');
}, 6000);

//Spring naar de volgende pagina na 7 seconden
setTimeout(function() {
  window.location = "VoidSelection.html";
}, 7000);
