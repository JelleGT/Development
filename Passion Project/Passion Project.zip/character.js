//Laat de sectie van het karakter zien van de karakterknop, waarop is gedrukt bij de vorige pagina
document.getElementById(currentCharacter).style.display = "block";
document.getElementById(currentCharacter + "Name").style.display = "block";
