setTimeout(function() {
    $('#intro').fadeOut('2000');
}, 6000);

setTimeout(function() {
  window.location = "VoidSelection.html";
}, 7000);
