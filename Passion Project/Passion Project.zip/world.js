document.getElementById(currentWorld).style.display = "block";
document.getElementById(currentWorld + "Name").style.display = "block";
